#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "node.h"
using namespace std;

class Inventory
{

private:
	Node *menuHead;
	Node *current;
	int size;

public:
	Inventory()
	{
		menuHead = NULL;
		current = NULL;
		size = 0;
		insertMenuItem("Corn Soup", 250, 1, "Soups", 20);
		insertMenuItem("Hot N Sour", 250, 2, "Soups", 20);
		// insertMenuItem("Thai Soup                      ", 400, 3, "Soups");
		insertMenuItem("Cappuccino", 150, 3, "Coffee", 30);
		insertMenuItem("Tea", 80, 4, "Coffee", 30);
		// insertMenuItem("Cafe Latte                     ", 200, 6, "Coffee");
		insertMenuItem("Chicken Cheese Burger", 400, 5, "Burgers", 25);
		insertMenuItem("B.B.Q Beef Burger", 600, 6, "Burgers", 25);
		// insertMenuItem("Charcoal Grilled Burger        ", 800, 9, "Burgers");
		insertMenuItem("Creamy Melt Pizza", 1500, 7, "Pizza", 30);
		// insertMenuItem("Behari Kebab Pizza             ", 1500, 11, "Pizza");
		// insertMenuItem("Chicken Supreme Pizza          ", 1300, 12, "Pizza");
		insertMenuItem("Cheese Lover Pizza", 1300, 8, "Pizza", 30);
		insertMenuItem("Crown Crush Pizza", 1800, 9, "Pizza", 30);
		insertMenuItem("Chicken Club Sandwich", 300, 10, "Sandwiches", 28);
		insertMenuItem("Grill Chicken Sandwich", 350, 11, "Sandwiches", 28);
		insertMenuItem("Smoke Chicken Sandwich", 350, 12, "Sandwiches", 28);
		// insertMenuItem("Chicken Tikka Sandwich         ", 300, 18, "Sandwiches");
		insertMenuItem("Mango Smoothie", 350, 13, "Smoothies", 40);
		insertMenuItem("Strawberry Smoothie", 400, 14, "Smoothies", 40);
		// // insertMenuItem("Blue-Berry Smoothie            ", 500, 21, "Smoothies");
		// insertMenuItem("Nun-bread                      ", 40, 22, "Breads");
		insertMenuItem("Coke", 50, 15, "Drinks", 35);
		insertMenuItem("Sprite", 50, 16, "Drinks", 35);
	}
	Node *gethead()
	{
		return menuHead;
	}

	void AdminOperations()
	{
		int choice;
		string name;
		float price;
		int id, quantity;
		string category;
	start:
		cout << "\n===================================" << endl;
		cout << "\n          Admin Management          " << endl;
		cout << "\n===================================\n"
			 << endl;
		cout << "1. Insert or Add Food Item in Menu " << endl;
		cout << "2. Update or Modify Food Item in Menu: " << endl;
		cout << "3. Remove Food Item By ID " << endl;
		cout << "4. Find Food Item By ID " << endl;
		cout << "5. Find Food Item By Name " << endl;
		cout << "6. Find Food Item By Category " << endl;
		cout << "7. Get Food Item By Index " << endl;
		cout << "8. View list of menu items " << endl;
		cout << "9. Check Order History " << endl;
		cout << "Enter your choice :  " << endl;
		cin >> choice;
		switch (choice)
		{
		case 1:

			cout << "Enter Food_ID : " << endl;
			cin >> id;
			cout << "Enter Name : " << endl;
			getline(cin >> ws, name);
			cout << "Enter Price : " << endl;
			cin >> price;
			cout << "Enter Category : " << endl;
			getline(cin >> ws, category);
			cout << "Enter Quantity : " << endl;
			cin >> quantity;
			insertMenuItem(name, price, id, category, quantity);
			cout << "Food Item added successfully!" << endl;
			displayMenu();
			break;

		case 2:
			updateItemByIndex();
			break;

		case 3:
			removeItemByIndex();
			break;

		case 4:
			findItemByIndex();
			break;

		case 5:
			findbyname();
			break;

		case 6:
			findbycategory();
			break;

		case 7:
			getByIndex();
			break;

		case 8:
			displayMenu();
			break;

		case 9:
			OrderHistory();
			break;

		default:
			cout << "Invalid Choice , Please Try Again!" << endl;
			break;
		}
		int subChoice;
		cout << "If you want to perform more operations in Admin Panel, press 1; otherwise, press any key" << endl;
		cin >> subChoice;
		if (subChoice != 1)
		{
			cout << "Exit Program!" << endl;
		}
		else
		{
			goto start;
		}
	}

	void insertMenuItem(string, float, int, string, int);
	void displayMenu();
	void displayMenuByCategory();
	void OrderHistory();
	void removeItemByIndex();
	void findItemByIndex();
	void findbyname();
	void findbycategory();
	void getByIndex();
	void updateItemByIndex();
};

void Inventory::insertMenuItem(string n, float p, int id, string cat, int q)
{
	Node *newItem = new Node(n, p, id, cat, q);
	if (!menuHead)
	{
		menuHead = newItem;
	}
	else
	{
		Node *temp = menuHead;
		while (temp->getnext() != NULL)
		{
			temp = temp->getnext();
		}
		temp->setnext(newItem);
	}
	size++;
}

void Inventory::displayMenu()
{
	cout << "                              ===============================                          " << endl;
	cout << "                              |             MENU            |                          " << endl;
	cout << "                              ===============================                          " << endl;

	cout << "==================================================================================================" << endl;
	cout << "| INDEX  |   ITEM NAME                      |  PRICE           |  CATEGORY      |  QUANTITY      |" << endl;
	cout << "==================================================================================================" << endl;
	Node *temp = menuHead;
	while (temp)
	{
		cout << "| " << setw(6) << temp->getfood_Id_No() << " | " << setw(30) << left << temp->getname()
			 << " | " << setw(12) << fixed << setprecision(2) << temp->getprice() << " | "
			 << setw(15) << temp->getcategory() << " | " << setw(15) << temp->getitemquantity() << " |" << endl;

		cout << "---------------------------------------------------------------------------------------------" << endl;
		temp = temp->getnext();
	}
}

void Inventory::displayMenuByCategory()
{
	string category;
	cout << "Enter category (e.g: Soups , Pizza , Sandwiches , Smoothies , Drinks , Burgers , Snacks , Coffee): ";
	cin >> category;

	cout << "                           ===============================                          " << endl;
	cout << "                           |      " << category << " MENU    |                          " << endl;
	cout << "                           ===============================                          " << endl;

	cout << "==================================================================================" << endl;
	cout << "| INDEX  |   ITEM NAME                      |  PRICE         |   QUANTITY        |" << endl;
	cout << "==================================================================================" << endl;
	Node *temp = menuHead;
	bool found = false;
	while (temp)
	{
		if (temp->getcategory() == category)
		{
			cout << "| " << setw(6) << temp->getfood_Id_No() << " | " << setw(30) << left << temp->getname()
				 << " | " << setw(12) << fixed << setprecision(2) << temp->getprice() << " | "
				 << setw(15) << temp->getitemquantity() << " |" << endl;

			cout << "----------------------------------------------------------------------------------" << endl;
			found = true;
		}
		temp = temp->getnext();
	}
	if (!found)
	{
		cout << "No items found in the specified category." << endl;
	}
}

void Inventory::updateItemByIndex()
{
	int id;
	cout << "Enter Food ID on which you want to update: " << endl;
	cin >> id;

	if (menuHead != nullptr)
	{
		Node *ptr = menuHead;
		bool found = false;

		while (ptr != nullptr)
		{
			if (ptr->getfood_Id_No() == id)
			{
				found = true;
				int choice;
				cout << "What do you want to update?" << endl;
				cout << "1. Name" << endl;
				cout << "2. Price" << endl;
				cout << "3. Quantity" << endl;
				cout << "4. Category" << endl;
				cout << "\nEnter your choice: ";
				cin >> choice;

				switch (choice)
				{
				case 1:
				{
					string name;
					cout << "Enter new name: ";
					getline(cin >> ws, name);
					ptr->setname(name);
					break;
				}
				case 2:
				{
					float price;
					cout << "Enter new price: ";
					cin >> price;
					ptr->setprice(price);
					break;
				}
				case 3:
				{
					int quantity;
					cout << "Enter new quantity: ";
					cin >> quantity;
					ptr->setitemquantity(quantity);
					break;
				}
				case 4:
				{
					string category;
					cout << "Enter new category: ";
					getline(cin >> ws, category);
					ptr->setcategory(category);
					break;
				}
				default:
					cout << "Invalid choice!" << endl;
					break;
				}

				cout << "Food Item Updated Successfully!" << endl;
				displayMenu();
				break;
			}
			ptr = ptr->getnext();
		}

		if (!found)
		{
			cout << "Invalid Food ID, Please try Again!" << endl;
		}
	}
	else
	{
		cout << "No Food Item Found!" << endl;
	}
}

void Inventory::removeItemByIndex()
{
	int id;
	cout << "Enter Food ID Which you want to remove:  " << endl;
	cin >> id;

	// Remove By Index

	// if (size > 0) {
	// 	if (id > 0 && id <= size) {
	// 		if (id == 1) {
	// 			current = menuHead;
	// 			current = current->getnext();
	// 			delete menuHead;
	// 			menuHead = current;
	// 			// size--;
	// 		} else if (id == size) {
	// 			Node *ptr = menuHead;
	// 			for (int i = 1; i < size - 1; i++) {
	// 				ptr = ptr->getnext();
	// 			}
	// 			current = ptr;
	// 			current = current->getnext();
	// 			ptr->setnext(NULL);
	// 			delete current;
	// 			current = ptr;
	// 			// size--;
	// 		} else {
	// 			Node *ptr = current = menuHead;
	// 			for (int i = 1; i < id - 1; i++) {
	// 				ptr = ptr->getnext();
	// 				current = current->getnext();
	// 			}
	// 			ptr = ptr->getnext();
	// 			current->setnext(ptr->getnext());
	// 			delete ptr;
	// 			// size--;
	// 		}
	// 		cout << "Item removed Successfully!" << endl;
	// 		displayMenu();
	// 	} else {
	// 		cout << "Invalid Food Index." << endl;
	// 	}
	// } else {
	// 	cout << "No Food Item." << endl;
	// }

	//  Remove by Food ID
	if (size > 0)
	{
		Node *current = menuHead;
		Node *previous = nullptr;
		bool found = false;

		while (current != nullptr)
		{
			if (current->getfood_Id_No() == id)
			{ // Assuming getItemId() gets the item's unique ID
				found = true;
				if (previous == nullptr)
				{ // Removing the first item
					menuHead = current->getnext();
					delete current;
				}
				else
				{
					previous->setnext(current->getnext());
					delete current;
				}
				size--;
				cout << "Item removed Successfully!" << endl;
				displayMenu();
				break;
			}
			previous = current;
			current = current->getnext();
		}

		if (!found)
		{
			cout << "Food ID not found. Cannot remove." << endl;
		}
	}
	else
	{
		cout << "No Food Item." << endl;
	}
}

void Inventory::findItemByIndex()
{
	int index;
	cout << "Enter Food ID on which you want to find food item:   " << endl;
	cin >> index;
	if (size > 0)
	{
		int compare = 0;
		Node *ptr = menuHead;
		while (ptr != nullptr)
		{
			if (ptr->getfood_Id_No() == index)
			{
				cout << "Food Item At ID : " << index << endl;
				cout << "Food ID : " << index << "\t"
					 << "Name : " << ptr->getname() << "\t"
					 << "Price: " << ptr->getprice() << "\t"
					 << "Category: " << ptr->getcategory() << "\t"
					 << "Quanitty: " << ptr->getitemquantity() << endl;
				compare = 1;
				break;
			}
			ptr = ptr->getnext();
		}
		if (compare == 0)
		{
			cout << "Item Not Found!" << endl;
		}
	}

	else
	{
		cout << "Item Not Found!" << endl;
	}
}

void Inventory::getByIndex()
{
	int Index;
	cout << "Enter Food ID on you want to get Food Item: " << endl;
	cin >> Index;
	if (size > 0)
	{
		int compare = 0;
		Node *ptr = menuHead;
		while (ptr != nullptr)
		{
			if (ptr->getfood_Id_No() == Index)
			{
				cout << "Food Item At ID :   " << Index << " is " << ptr->getname() << endl;
				compare = 1;
				break;
			}
			ptr = ptr->getnext();
		}
			if (compare == 0)
			{
				cout << "Invalid Food ID!" << endl;
			}
		
	}
	else
	{
		cout << "Food Item Not Found!" << endl;
	}
}

void Inventory::findbyname()
{
	string name;
	cout << "Enter Item Name to find Food Item :  " << endl;
	getline(cin >> ws, name);

	// Add input validation
	if (name.empty())
	{
		cout << "Invalid category entered!" << endl;
		return;
	}

	if (size > 0)
	{
		int compare = 0;
		Node *ptr = menuHead;
		while (ptr != nullptr)
		{
			if (ptr->getname() == name)
			{
				cout << "====================================================================================" << endl;
				cout << "Food Item : " << name << endl;
				cout << "Food ID : " << ptr->getfood_Id_No() << "\t"
					 << "Name : " << name << "\t"
					 << "Price: " << ptr->getprice() << "\t"
					 << "Category: " << ptr->getcategory() << "\t"
					 << "Quanitty: " << ptr->getitemquantity() << endl;
				cout << "====================================================================================" << endl;
				compare = 1;
				break;
			}
			ptr = ptr->getnext();
		}
		if (compare == 0)
		{
			cout << "Item Not Found!" << endl;
		}
	}

	else
	{
		cout << "Item Not Found!" << endl;
	}
}

void Inventory::findbycategory()
{
	string category;
	cout << "Enter Category to find Food Item :  " << endl;
	getline(cin >> ws, category);

	// Add input validation
	if (category.empty())
	{
		cout << "Invalid category entered!" << endl;
		return;
	}

	if (size > 0)
	{
		int compare = 0;
		Node *ptr = menuHead;
		while (ptr != nullptr)
		{
			if (ptr->getcategory() == category)
			{
				cout << "======================================================================================================" << endl;
				cout << "Food Category : " << category << endl;
				cout << "Food ID : " << ptr->getfood_Id_No() << "\t"
					 << "Name : " << ptr->getname() << "    "
					 << "Price: " << ptr->getprice() << "\t"
					 << "Category: " << category << "    "
					 << "Quanitty: " << ptr->getitemquantity() << endl;
				cout << "=====================================================================================================" << endl;
				compare = 1;
			}
			ptr = ptr->getnext();
		}
		if (compare == 0)
		{
			cout << "Item Not Found!" << endl;
		}
	}

	else
	{
		cout << "Item Not Found!" << endl;
	}
}
