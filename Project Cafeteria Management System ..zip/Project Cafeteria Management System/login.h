#include<iostream>
#include<string>
using namespace std;
string username="cafecito";
string password="beans";
void identification() {
	string u;
	cout << "\t\t\t=================================== "<<endl;
	cout << "\n\t\t\t         Login Details        \n\n";
	cout << "\t\t\t=================================== "<<endl;
	cout<<"\n\t\t\tEnter Username: ";
user:
	getline(cin>>ws,u);
	if(username!=u) {
		cout<<"\t\t\tInvalid Username Enter Again ";
		goto user;
	}
	cout<<"\n\t\t\tEnter Password: ";
pass:
	getline(cin>>ws,u);
	if(password!=u) {
		cout<<"\t\t\tInvalid Password Enter Again ";
		goto pass;
	} else {
		cout << "\t\t\t========================================"<<endl;
		cout << "\n\t\t\tAccess Granted! Logged In Successfully \n"<<endl;
		cout << "\t\t\t========================================"<<endl;
	}
}

