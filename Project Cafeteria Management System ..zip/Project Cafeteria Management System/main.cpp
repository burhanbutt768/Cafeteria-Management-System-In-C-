#include <iostream>
#include <string>
// #include <Windows.h>
#include <ctime>
#include <fstream>
#include "Inventory.h"
#include "login.h"
#include "stylename.h"
using namespace std;

// ANSI escape codes for text colors
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define MAGENTA "\033[35m"
#define BG_CYAN    "\033[36m"
#define WHITE   "\033[37m"

// ANSI escape codes for text and background colors
#define RESET       "\033[0m"
#define TEXT_RED    "\033[31m"
#define TEXT_GREEN  "\033[32m"
#define BG_YELLOW   "\033[43m"
#define BG_BLUE     "\033[44m"

int orderNumber;

class ordereditem
{
public:
    int ordereditem_id;
    string ordereditem_name;
    int quantity;
    float price;
    string feedback;
    int rating;
    ordereditem *next;

    ordereditem(int ordereditem_id, string ordereditem_name, int quantity, float price)
    {
        next = NULL;
        set_ordereditemid(ordereditem_id);
        set_ordereditemname(ordereditem_name);
        set_ordereditemquantity(quantity);
        setprice(price);
    }
    ordereditem(string feedback, int rating)
    {
        next = NULL;
        setfeedback(feedback, rating);
    }
    void setfeedback(string feedback, int rating)
    {
        this->feedback = feedback;
        this->rating = rating;
    }
    void set_ordereditemid(int id)
    {
        ordereditem_id = id;
    }
    int get_ordereditemid()
    {
        return ordereditem_id;
    }
    void set_ordereditemname(string name)
    {
        ordereditem_name = name;
    }
    string get_ordereditemname()
    {
        return ordereditem_name;
    }
    void set_ordereditemquantity(int q)
    {
        quantity = q;
    }
    int get_ordereditemquantity()
    {
        return quantity;
    }
    void setprice(float p)
    {
        price = p;
    }
    float getprice()
    {
        return price;
    }
    void setnext(ordereditem *ptr)
    {
        next = ptr;
    }
    ordereditem *getnext()
    {
        return next;
    }

};

class ordermanage
{
private:

    ordereditem *head;
    ordereditem *current;
    string feedback;
    int rating;
    int size;
   
    Inventory &i1;

public:
    void add(int, string, int, float);
    ordermanage(Inventory &inventoryinstance) : i1(inventoryinstance)
    
    {
        head = NULL;
        current = NULL;
        size = 0;
    }
    void placeOrder();
    double Invoice(int);
    void addFeedback();
    void displayFeedback();
    void modifyOrder();
    void removeItemByIndex();
    void updateItemByIndex();
    void CustomerOperations();
    void clearlist();
};

void ordermanage::CustomerOperations()
    {
        int choice;
        cout << "--------------------------------------------" << endl;
        cout << "                    MENU                    " << endl;
        cout << "--------------------------------------------" << endl;
    start:
        cout << "1. Display Food Menu " << endl;
        cout << "2. Display Food Menu By Category " << endl;
        cout << "3. Place Order " << endl;
        cout << "4. Exit"<<endl;
        cin >> choice;
        switch (choice)
        {
        case 1:
            i1.displayMenu();
            break;

        case 2:
            i1.displayMenuByCategory();
            break;

        case 3:
            placeOrder();
            modifyOrder();
            addFeedback();
            displayFeedback();
            break;

        case 4:
            cout << "Thank you for visiting!"<<endl;
            break;

        default:
            cout << "Invalid Choice , Please Try Again!" << endl;
            break;
        }
        int subChoice;
        cout << "If you want to perform more operations in Customer Panel, press 1; otherwise, press any key" << endl;
        cin >> subChoice;
        if (subChoice != 1)
        {
            cout << "----------------------------------------" << endl;
            cout << "|    Enjoy Your Meal, GoodBye!         |" << endl;
            cout << "----------------------------------------" << endl;
        }
        else
        {
            clearlist();
            goto start;
        }
    }


void ordermanage::add(int id, string name, int quantity, float price)
{
    ordereditem* ptr = new ordereditem(id,name,quantity,price);
    if(head==NULL)
    {
        head=current=ptr;
    }
    else
    {
        current->setnext(ptr);
        current=ptr;
    }
    size++;
}

void ordermanage::placeOrder()
{
    int food_id;
    int quantity;
    int n, m;
    float totalAmount = 0.0;

    Node *ptr;
    i1.displayMenu();
    do
    {
    start:
        ptr = i1.gethead();
        cout << "Please Enter the Food_ID ";
        cin >> food_id;
    retake:
        cout << "Enter Quantity ";
        cin >> quantity;

        ordereditem *orderedItemPtr = head;
        bool found = false;
        
        while ((ptr && ptr->getfood_Id_No() != food_id) && (ptr != NULL))
            {
            
                ptr = ptr->getnext();
            }
            if (quantity > ptr->getitemquantity())
            {
                cout << "Invalid Quantity" << endl;
                goto retake;
            }
        // Check if the food_id is already present in ordered items
        while (orderedItemPtr != nullptr)
        {
            if (orderedItemPtr->get_ordereditemid() == food_id)
            {
                found = true;
                // Increment the quantity
                  ptr->setitemquantity(ptr->getitemquantity() - quantity);
                orderedItemPtr->set_ordereditemquantity(orderedItemPtr->get_ordereditemquantity() + quantity);
                cout << "Quantity updated for Food ID: " << food_id << endl;
                break;
            }
            orderedItemPtr = orderedItemPtr->getnext();
        }

        if (!found)
        {
            // Check if food_id is valid
            // while ((ptr && ptr->getfood_Id_No() != food_id) && (ptr != NULL))
            // {
            
            //     ptr = ptr->getnext();
            // }
            // if (quantity > ptr->getitemquantity())
            // {
            //     cout << "Invalid Quantity" << endl;
            //     goto retake;
            // }
            if (ptr)
            {   
                  ptr->setitemquantity(ptr->getitemquantity() - quantity);
                add(ptr->getfood_Id_No(), ptr->getname(), quantity, ptr->getprice());
            }
            else
            {
                cout << "Invalid Food ID." << endl;
                return;
            }

            
        }
        cout << "Do you want to order more items? (1 for Yes, 0 for No): ";
            cin >> n;
       
    } while (n == 1);
}

// void ordermanage::placeOrder()
// {
//     int food_id;
//     int quantity;
//     int n, m;
//     float totalAmount = 0.0;

//     i1.displayMenu();
//     Node *ptr;
//     do
//     {
//     start:
//         ptr = i1.gethead();
//         cout << "Please Enter the Food_ID ";
//         cin >> food_id;
//     retake:
//         cout << "Enter Quantity ";
//         cin >> quantity;

//         ordereditem *orderedItemPtr = head;
//         bool found = false;

//         // Check if the food_id is already present in ordered items
//         while (orderedItemPtr != nullptr)
//         {
//             if (orderedItemPtr->get_ordereditemid() == food_id)
//             {
//                 found = true;
//                 // Increment the quantity
//                 orderedItemPtr->set_ordereditemquantity(orderedItemPtr->get_ordereditemquantity() + quantity);
//                 cout << "Quantity updated for Food ID: " << food_id << endl;
//                 break;
//             }
//             orderedItemPtr = orderedItemPtr->getnext();
//         }

//         if (!found)
//         {
//             // Check if food_id is valid
//             while ((ptr && ptr->getfood_Id_No() != food_id) && (ptr != NULL))
//             {
//                 ptr = ptr->getnext();
//             }
//             if (quantity > ptr->getitemquantity())
//             {
//                 cout << "Invalid Quantity" << endl;
//                 goto retake;
//             }
//             if (ptr)
//             {
//                 add(ptr->getfood_Id_No(), ptr->getname(), quantity, ptr->getprice());
//             }
//             else
//             {
//                 cout << "Invalid Food ID." << endl;
//                 return;
//             }

            
//         }
//         cout << "Do you want to order more items? (1 for Yes, 0 for No): ";
//             cin >> n;
       
//     } while (n == 1);
            
// }

double ordermanage::Invoice(int orderNumber) {
        double totalAmount = 0.0;
        string customerName;
        string phoneNumber;
        const double cashSalesTaxRate = 0.17;
        const double cardSalesTaxRate = 0.05;
        string paymentMethod;
        double salesTax;
        
        time_t t = time(0);
        struct tm* now = localtime(&t);
        char date[80];
        char time[80];
        strftime(date, 80, "%Y-%m-%d", now);
        strftime(time, 80, "%X", now);

        cout << "Enter your Name: ";
        getline(cin >> ws, customerName);
        cout << "Enter Phone Number: ";
        getline(cin >> ws, phoneNumber);

        ordereditem* ptr1 = head;
        cout << "\n=================== Item you ordered ===================   \n"<<endl;
        while (ptr1 != nullptr) {
            totalAmount += (ptr1->get_ordereditemquantity() * ptr1->getprice());

            // Add item details to the bill file
            cout << ptr1->get_ordereditemid() << "\t     " << ptr1->get_ordereditemname() << "\t"
                 << ptr1->get_ordereditemquantity() << " " << (ptr1->get_ordereditemquantity() * ptr1->getprice()) << endl;

            ptr1 = ptr1->getnext();
        }
        cout << "\n========================================================    \n"<<endl;

        // Check payment method and calculate total amount and sales tax
        cout << "How would you like to pay? (cash/card): ";
        getline(cin>>ws,paymentMethod);

        string fileName = "order_" + to_string(orderNumber) + "_bill.txt";
        ofstream billFile(fileName);

        billFile << "======================== Invoice =========================" << endl;
        billFile << "Customer Name:        " << customerName << endl;
        billFile << "Phone Number:         " << phoneNumber << endl;
        billFile << "Date: " << date << endl;
        billFile << "Time: " << time << endl;
        billFile << "----------------------------------------------------------" << endl;
        billFile << "   Item ID |  Item Name              | Quantity |   Amount" << endl;
		billFile << "----------------------------------------------------------" << endl;

        // Continue printing item details to the bill file
        ptr1 = head;
        while (ptr1 != nullptr) {
          billFile << setw(12) << ptr1->get_ordereditemid() << setw(26) << ptr1->get_ordereditemname()
             << setw(10) << ptr1->get_ordereditemquantity() << setw(10) << (ptr1->get_ordereditemquantity() * ptr1->getprice()) << endl;

            ptr1 = ptr1->getnext();
}

        billFile << "-----------------------------------------------------------" << endl;
        // ptr1 = head;
        // while (ptr1 != nullptr) {
        //     billFile << ptr1->get_ordereditemid() << "\t     " << ptr1->get_ordereditemname() << "\t"
        //              << ptr1->get_ordereditemquantity() << " " << (ptr1->get_ordereditemquantity() * ptr1->getprice()) << endl;

        //     ptr1 = ptr1->getnext();
        // }

        // billFile << "-----------------------------------------------------------" << endl;

        if (paymentMethod == "cash") {
            salesTax = totalAmount * cashSalesTaxRate;
        } else if (paymentMethod == "card") {
            salesTax = totalAmount * cardSalesTaxRate;
        } else {
            cout << "Invalid payment method. Please choose 'cash' or 'card'." << endl;
            billFile << "Invalid payment method. Please choose 'cash' or 'card'." << endl;
            billFile.close(); // Close the file
            return -1;        // Return -1 to indicate an error
        }

        billFile << "                        Sales Tax:                $" << salesTax << endl;
        billFile << "                        Total Amount:             $" << totalAmount + salesTax << endl;
        billFile << "=======================================================" << endl;

        billFile.close(); // Close the file

        // Open Notepad with the file
        system(("start notepad.exe " + fileName).c_str());

        return totalAmount + salesTax;
    }

void ordermanage::addFeedback()
{
    string feedback;
    int rating;
    cout << "Share your Feedback / Message for Cafeteria Services :  " << endl;
    getline(cin>>ws,feedback);
start:
    cout << "Rate their Food / Beverages quality (1-5) :  " << endl;
    cin >> rating;
    ordereditem* ptr = new ordereditem(feedback, rating);
    if (rating <= 5)
    {
        ptr->setnext(head);
        head = ptr;
    }
    else
    {
        cout << " Invalid Rating, Please Try Again!" << endl;
        goto start;
    }
}

void ordermanage::displayFeedback()
{
    ordereditem *current = head;
    cout << "Customer Feedback:\n";
    if(size>0){
    {
        cout << "Rating: " << current->rating << "\n";
        cout << "Message: " << current->feedback << "\n\n";
        current = current->getnext();
    }
     cout << "Thank You For Your Feedback!\n"<< endl;
    }
    else
    {
        cout << "Feedback Not required!"<<endl;
    }
}

void ordermanage::updateItemByIndex()
{
    int index;
    int quantity;
    string customerName;
    string phoneNumber;
    ordereditem *ptr1 = head;
    cout << "Enter Food ID on which you want to update:   " << endl;
    cin >> index;
retake:
    cout << "Enter New Quantity To Modify Food Item:  " << endl;
    cin >> quantity;

    if (head != nullptr)
    {
        ordereditem *ptr = head;
        bool found = false;
        Node *ptr3 = i1.gethead();
        while (ptr3 != nullptr)
        {
            if (ptr3->getfood_Id_No() == index)
            {
                break;
            }
            ptr3 = ptr3->getnext();
        }
        while (ptr != nullptr)
        {
            if (ptr->get_ordereditemid() == index)
            {
                found = true;
                int currentQuantity = ptr3->getitemquantity(); // Get the existing quantity from the inventory
                int newQuantity = currentQuantity + ptr->get_ordereditemquantity();
                ptr3->setitemquantity(newQuantity);
                if (quantity > ptr3->getitemquantity())
                {
                    cout << "Invalid Quantity" << endl;
                    goto retake;
                }
                
                ptr->set_ordereditemquantity(quantity);
                ptr3->setitemquantity(ptr3->getitemquantity()-quantity);
                cout << "Food Item Updated Successfully!" << endl;
                // Invoice(orderNumber);
                break;
            }
            ptr = ptr->getnext();
        }

        if (!found)
        {
            cout << "Invalid Food ID, Please try Again!" << endl;
        }
    }
    else
    {
        cout << "No Food Item Found!" << endl;
    }
}

// void ordermanage::updateItemByIndex()
// { 
//     int index;
//     int quantity;
//     string customerName;
//     string phoneNumber;
//      ordereditem* ptr1=head;
//     cout << "Enter Food ID on which you want to update:   " << endl;
//     cin >> index;
//     retake:
//     cout << "Enter New Quantity To Modify Food Item:  " << endl;
//     cin >> quantity;

//     if (head != nullptr) {
//     ordereditem *ptr = head;
//     bool found = false;
//     Node * ptr3=i1.gethead();
//     while(ptr3!=nullptr){
//         if(ptr3->getfood_Id_No()==index){
//             break;
//         }
//         ptr3=ptr3->getnext();
//     }
//     while (ptr != nullptr) {
//         if (ptr->get_ordereditemid() == index) {
//             found = true;
//             if(quantity>ptr3->getitemquantity()){
//                 cout<<"Invalid Quantity"<<endl;
//                 goto retake;
//             }
//             ptr->set_ordereditemquantity(quantity);
//             cout << "Food Item Updated Successfully!" << endl;
//             // Invoice(orderNumber);
//             break;
//         }
//         ptr = ptr->getnext();
//     }

//     if (!found) {
//         cout << "Invalid Food ID, Please try Again!" << endl;
//     }
// } else {
//     cout << "No Food Item Found!" << endl;
// }
   
// }


// void ordermanage::removeItemByIndex()
// {
//     int id;
//     cout << "Enter Food Index Which you want to remove:  " << endl;
//     cin >> id;
 
//     if (size > 0) {
//         ordereditem *current = head;
//         ordereditem *previous = nullptr;
//         bool found = false;

//         while (current != nullptr) {
//             if (current->get_ordereditemid() == id) { // Assuming getItemId() gets the item's unique ID
//                 found = true;
//                 if (previous == nullptr) { // Removing the first item
//                     head = current->getnext();
//                     delete current;
//                 } else {
//                     previous->setnext(current->getnext());
//                     delete current;
//                 }
//                 size--;
//                 cout << "Item removed Successfully!" << endl;
//                 break;
//             }
//             previous = current;
//             current = current->getnext();
//         }

//         if (!found) {
//             cout << "Food ID not found. Cannot remove." << endl;
//         }
//         // Invoice(orderNumber);
//     } else {
//         cout << "No Food Item." << endl;
//     }
// }

void ordermanage::removeItemByIndex()
{
    int id;
    cout << "Enter Food Index Which you want to remove:  " << endl;
    cin >> id;

    if (size > 0)
    {
        ordereditem *current = head;
        ordereditem *previous = nullptr;
        bool found = false;

        while (current != nullptr)
        {
            if (current->get_ordereditemid() == id)
            { // Assuming getItemId() gets the item's unique ID
                found = true;
                 Node *ptr3 = i1.gethead(); // Pointer to the inventory list
                while (ptr3 != nullptr)
                {
                    if (ptr3->getfood_Id_No() == id)
                    {
                        // Increase inventory quantity
                        ptr3->setitemquantity(ptr3->getitemquantity() + current->get_ordereditemquantity());
                        break;
                    }
                    ptr3 = ptr3->getnext();
                }
                if (previous == nullptr)
                { // Removing the first item
                    head = current->getnext();
                    delete current;
                }
                else
                {
                    previous->setnext(current->getnext());
                    delete current;
                }
                size--;
                cout << "Item removed Successfully!" << endl;
                break;
            }
            previous = current;
            current = current->getnext();
        }

        if (!found)
        {
            cout << "Food ID not found. Cannot remove." << endl;
        }
        // Invoice(orderNumber);
    }
    else
    {
        cout << "No Food Item." << endl;
    }
}

void ordermanage::modifyOrder()
{
    int choice;
start:
    cout << "1. Add Something To Your Order"<< endl;
    cout << "2. Modify Order  "<<endl;
    cout << "3. Cancel Order" <<endl;
    cout << "4. Don't want any change!"<<endl;
    cin >>choice;
    switch(choice){
        case 1:{
            i1.displayMenu();
            placeOrder();
            break;
        }
        case 2:
        {
            updateItemByIndex();
            break;
        }
        case 3:
        {
            removeItemByIndex();
            break;
        }
        case 4:
        {
            
            break;
        }

        default:
        {
            cout << "Invalid Choice , Please Try Again!"<<endl;
            break;
        }     
    }
    int subChoice;
    cout << "Do you want to modify/add/cancel again? (1 for Yes , 0 for No) : " << endl;
    cin >> subChoice;
    if (subChoice != 1)
    {   
        Invoice(++orderNumber);
        cout << "\n-----------------------------------------\n"<<endl;
    }
    else
    {
        goto start;
    }
}


    void Inventory::OrderHistory() {
    int orderNum = 1;
    string line;

    while (orderNum<=orderNumber) {
        string fileName = "order_" + to_string(orderNum) + "_bill.txt";
        ifstream billFile(fileName);

        if (!billFile.is_open()) {
            cout << "No more orders found!" << endl;
            break;
        }

        cout << "====================== Order " << orderNum << " ======================" << endl;
        while (getline(billFile, line)) {
            cout << line << endl;
        }
        cout << "===================================================" << endl;

        billFile.close();
        orderNum++;
    }
}


void ordermanage :: clearlist(){
    ordereditem* ptr=current=head;
    while(ptr!=NULL){
        current=current->getnext();
        delete ptr;
        ptr=current;
    }
    head=current=NULL;
    size=0;
}

int main()
{

    Inventory i;
    ordermanage o(i);
    
    ifstream orderFile("orderNumber.txt");
    if (orderFile.is_open()) {
        orderFile >> orderNumber;
        orderFile.close();
    } else {
        cout << "File for order number does not exist or cannot be opened!" << endl;
        // Initialize orderNumber to 0 or any default value
        orderNumber = 0;
    }
    // system ("color E4");
    // system("Color B5");
    // system("Color DE");
    // system("Color FE");
    // system ("color 0a");
    system ("color 10");
    // system("Color 3E");
    CafecitoBeans();
    team();
    int choice;
    cout << "          \n\t\t============================================================\n";
    cout <<             "\t\t|                  WELCOME TO CAFECITO BEANS               |";
    cout << "          \n\t\t============================================================\n";
start:
    cout << "\n                               MAIN MENU                   " << endl;

    cout << "                             1. Admin Panel" << endl;
    cout << "                             2. Customer Panel" << endl;
    cout << "                             3. Exit" << endl;
    cout << "                        \n\t\t\tEnter your choice  :  ";
    cin>>choice;
     ofstream orderFileOut("orderNumber.txt");
   switch(choice) {
    case 1:
        identification();
        i.AdminOperations();
        break;

    case 2:
        o.CustomerOperations();
        break;

    case 3:
       
            if (orderFileOut.is_open()) {
                orderFileOut << orderNumber;
                orderFileOut.close();
            } else {
                cout << "Unable to save order number to file!" << endl;
            }
        cout << "             ----------------------------------------" << endl;
        cout << "             |    Enjoy Your Meal, GoodBye!         |" << endl;
        cout << "             ----------------------------------------" << endl;
        break;

    default:
        cout << "             Invalid Choice , Try Again!" << endl;
        break;
    }
    int subChoice;
    while(choice==1 || choice == 2)
    {
    cout << "If you want to perform more operations in Main Menu , press 1; otherwise, press any key" << endl;
    cin >> subChoice;
    if (subChoice != 1)
    {
        
            if (orderFileOut.is_open()) {
                orderFileOut << orderNumber;
                orderFileOut.close();
            } else {
                cout << "Unable to save order number to file!" << endl;
            }
        cout << "Exit Program!" << endl;
		break;
    }
    else
    {
        goto start;
    }  
  }
}
