#include <iostream>
#include <string>
using namespace std;
class Node {
	public:
		string name;
		float price;
		int food_Id_No;
		string category; // Added category field
		Node *next;
		int quantity;
		int itemquantity;
		double totalPrice;

		Node(string name, float price, int food_Id_No, string category, int itemquantity) {
			next = NULL;
			setdata(name, price, food_Id_No, category,itemquantity);
		}

		void setdata(string name, float price, int food_Id_No, string category ,int itemquantity) {
			this->food_Id_No = food_Id_No;
			this->name = name;
			this->category = category;
			this->price = price;
			this->itemquantity=itemquantity;
		}
		void getdata() {
			cout << getfood_Id_No() << " " << getname() << "  " << getitemquantity() << " " << (getitemquantity() * getprice()) << endl;
		}

		void setnext(Node *ptr) {
			next = ptr;
		};
		Node *getnext() {
			return next;
		};
		void setname(string n) {
			name = n;
		};
		string getname() {
			return name;
		};
		void setprice(float p) {
			price = p;
		};
		float getprice() {
			return price;
		};
		void setfood_Id_No(int f) {
			food_Id_No = f;
		};
		int getfood_Id_No() {
			return food_Id_No;
		};
		// void setquantity(int q) {
		// 	quantity = q;
		// };
		void setitemquantity(int q) {
			itemquantity = q;
		}
		int getitemquantity() {

			return itemquantity;
		};
		// int getquantity() {

		// 	return quantity;
		// };
		void setcategory(string c) {
			category = c;
		};
		string getcategory() {
			return category;
		};
};
